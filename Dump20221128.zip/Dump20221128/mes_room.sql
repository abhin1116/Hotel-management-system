-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: mes
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `RoomNumber` int NOT NULL,
  `RoomType` varchar(30) NOT NULL,
  `BlockFloor` int NOT NULL,
  `BlockCode` int NOT NULL,
  `Unavailable` bit(1) NOT NULL,
  PRIMARY KEY (`RoomNumber`),
  KEY `fk_Room_Block_PK` (`BlockFloor`,`BlockCode`),
  CONSTRAINT `fk_Room_Block_PK` FOREIGN KEY (`BlockFloor`, `BlockCode`) REFERENCES `block` (`BlockFloor`, `BlockCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (101,'Single',1,1,_binary '\0'),(102,'Single',1,1,_binary '\0'),(103,'Single',1,1,_binary '\0'),(111,'Single',1,2,_binary '\0'),(112,'Single',1,2,_binary ''),(113,'Single',1,2,_binary '\0'),(121,'Single',1,3,_binary '\0'),(122,'Single',1,3,_binary '\0'),(123,'Single',1,3,_binary '\0'),(201,'Single',2,1,_binary ''),(202,'Single',2,1,_binary '\0'),(203,'Single',2,1,_binary '\0'),(211,'Single',2,2,_binary '\0'),(212,'Single',2,2,_binary '\0'),(213,'Single',2,2,_binary ''),(221,'Single',2,3,_binary '\0'),(222,'Single',2,3,_binary '\0'),(223,'Single',2,3,_binary '\0'),(301,'Single',3,1,_binary '\0'),(302,'Single',3,1,_binary ''),(303,'Single',3,1,_binary '\0'),(311,'Single',3,2,_binary '\0'),(312,'Single',3,2,_binary '\0'),(313,'Single',3,2,_binary '\0'),(321,'Single',3,3,_binary ''),(322,'Single',3,3,_binary '\0'),(323,'Single',3,3,_binary '\0'),(401,'Single',4,1,_binary '\0'),(402,'Single',4,1,_binary ''),(403,'Single',4,1,_binary '\0'),(411,'Single',4,2,_binary '\0'),(412,'Single',4,2,_binary '\0'),(413,'Single',4,2,_binary '\0'),(421,'Single',4,3,_binary ''),(422,'Single',4,3,_binary '\0'),(423,'Single',4,3,_binary '\0');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-28  1:50:49
